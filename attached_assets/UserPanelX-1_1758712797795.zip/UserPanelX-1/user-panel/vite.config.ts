// Simple Vite config without imports to avoid module resolution issues
export default {
  server: {
    host: '0.0.0.0',
    port: 5000
  },
  build: {
    target: 'esnext'
  }
}