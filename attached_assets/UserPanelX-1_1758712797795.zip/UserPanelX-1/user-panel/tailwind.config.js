/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        dark: {
          100: '#212121',
          200: '#121212',
        },
        primary: {
          DEFAULT: '#1E88E5',
          hover: '#1976D2',
        },
        accent: {
          DEFAULT: '#F9A825',
          hover: '#F57F17',
        },
        success: {
          DEFAULT: '#00C853',
          hover: '#00A844',
        },
        error: {
          DEFAULT: '#D32F2F',
          hover: '#B71C1C',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
}