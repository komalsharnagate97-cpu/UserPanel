import React, { useState } from 'react';
import { Users, Share2, DollarSign, Copy, TrendingUp, Gift, Award } from 'lucide-react';
import type { ReferralData } from '../types';

const ReferralProgram: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState<number>(1);

  const referralLink = "https://userpanel.com/ref/UP123456";
  
  const walletBalance = 2450;
  const totalReferrals = 47;
  const thisMonthEarnings = 680;

  const referralLevels: ReferralData[] = [
    {
      level: 1,
      count: 23,
      earnings: 1150,
      users: [
        { name: 'Alex Johnson', joinDate: '2024-09-15', earnings: 89 },
        { name: 'Sarah Wilson', joinDate: '2024-09-12', earnings: 156 },
        { name: 'Mike Davis', joinDate: '2024-09-10', earnings: 134 },
        { name: 'Emma Brown', joinDate: '2024-09-08', earnings: 201 },
        { name: 'John Smith', joinDate: '2024-09-05', earnings: 178 }
      ]
    },
    {
      level: 2,
      count: 16,
      earnings: 820,
      users: [
        { name: 'Lisa Garcia', joinDate: '2024-09-14', earnings: 67 },
        { name: 'Tom Anderson', joinDate: '2024-09-11', earnings: 89 },
        { name: 'Anna Lee', joinDate: '2024-09-09', earnings: 123 },
        { name: 'Chris Taylor', joinDate: '2024-09-07', earnings: 95 },
        { name: 'Maria Rodriguez', joinDate: '2024-09-04', earnings: 134 }
      ]
    },
    {
      level: 3,
      count: 8,
      earnings: 480,
      users: [
        { name: 'David Kim', joinDate: '2024-09-13', earnings: 45 },
        { name: 'Sophie Chen', joinDate: '2024-09-10', earnings: 78 },
        { name: 'Jake Miller', joinDate: '2024-09-08', earnings: 67 },
        { name: 'Rachel Green', joinDate: '2024-09-06', earnings: 89 },
        { name: 'Ryan White', joinDate: '2024-09-03', earnings: 56 }
      ]
    }
  ];

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.log('Failed to copy referral link');
    }
  };

  const handleShareLink = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join Our Amazing Platform!',
        text: 'I\'ve been using this platform to grow my business. Join me and get started!',
        url: referralLink,
      });
    } else {
      handleCopyLink();
    }
  };

  const handleWithdraw = () => {
    console.log('Withdrawal initiated');
    alert(`Withdrawal request initiated for $${walletBalance}\n\nThis is a demo - no real withdrawal will be processed.\n\nFunds would typically be transferred within 2-3 business days.`);
  };

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card bg-gradient-to-br from-success/20 to-success/10 border-success/30">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-success/20 rounded-lg">
              <DollarSign className="text-success" size={24} />
            </div>
            <span className="text-success text-sm font-medium">Available</span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">
            ${walletBalance.toLocaleString()}
          </h3>
          <p className="text-gray-400 text-sm">Wallet Balance</p>
        </div>

        <div className="card bg-gradient-to-br from-primary/20 to-primary/10 border-primary/30">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-primary/20 rounded-lg">
              <Users className="text-primary" size={24} />
            </div>
            <span className="text-primary text-sm font-medium">Total</span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">
            {totalReferrals}
          </h3>
          <p className="text-gray-400 text-sm">Total Referrals</p>
        </div>

        <div className="card bg-gradient-to-br from-accent/20 to-accent/10 border-accent/30">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-accent/20 rounded-lg">
              <TrendingUp className="text-accent" size={24} />
            </div>
            <span className="text-accent text-sm font-medium">This Month</span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">
            ${thisMonthEarnings}
          </h3>
          <p className="text-gray-400 text-sm">Month Earnings</p>
        </div>
      </div>

      {/* Referral Link Section */}
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white flex items-center">
            <Share2 className="mr-3 text-primary" size={24} />
            Your Referral Link
          </h3>
          <div className="flex items-center space-x-2">
            <Gift className="text-accent" size={20} />
            <span className="text-accent font-medium text-sm">50% Commission</span>
          </div>
        </div>

        <div className="bg-dark-200 p-4 rounded-lg mb-4">
          <div className="flex items-center justify-between">
            <code className="text-primary font-mono text-sm break-all">
              {referralLink}
            </code>
            <button
              onClick={handleCopyLink}
              className={`ml-4 px-4 py-2 rounded-lg font-medium transition-all ${
                copied 
                  ? 'bg-success text-white' 
                  : 'bg-primary hover:bg-primary-hover text-white'
              }`}
            >
              {copied ? 'Copied!' : <Copy size={16} />}
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button onClick={handleShareLink} className="btn-primary flex-1">
            <Share2 size={16} className="mr-2" />
            Share Link
          </button>
          <button onClick={handleWithdraw} className="btn-success flex-1">
            <DollarSign size={16} className="mr-2" />
            Withdraw ${walletBalance}
          </button>
        </div>
      </div>

      {/* Referral Levels */}
      <div className="card">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <Award className="mr-3 text-accent" size={24} />
          3-Level Referral Chain
        </h3>

        {/* Level Tabs */}
        <div className="flex border-b border-gray-700 mb-6">
          {referralLevels.map((level) => (
            <button
              key={level.level}
              onClick={() => setSelectedLevel(level.level)}
              className={`px-6 py-3 font-medium transition-all ${
                selectedLevel === level.level
                  ? 'text-primary border-b-2 border-primary'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Level {level.level} ({level.count})
            </button>
          ))}
        </div>

        {/* Selected Level Content */}
        {referralLevels.map((level) => (
          selectedLevel === level.level && (
            <div key={level.level} className="animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-dark-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Users</h4>
                  <p className="text-2xl font-bold text-primary">{level.count}</p>
                </div>
                <div className="bg-dark-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Total Earnings</h4>
                  <p className="text-2xl font-bold text-success">${level.earnings}</p>
                </div>
                <div className="bg-dark-200 p-4 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">Avg per User</h4>
                  <p className="text-2xl font-bold text-accent">
                    ${Math.round(level.earnings / level.count)}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold text-white mb-3">Recent Referrals</h4>
                {level.users.map((user, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-dark-200 rounded-lg hover:bg-dark-100 transition-colors">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center mr-3">
                        <span className="text-white font-medium">
                          {user.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-white">{user.name}</p>
                        <p className="text-gray-400 text-sm">
                          Joined: {new Date(user.joinDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-success">${user.earnings}</p>
                      <p className="text-gray-400 text-sm">Earnings</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        ))}
      </div>

      {/* Program Information */}
      <div className="card bg-gradient-to-r from-primary/10 to-accent/10 border-primary/30">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <Gift className="mr-3 text-accent" size={24} />
          How It Works
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-white font-bold text-xl">1</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Level 1 - 50%</h4>
            <p className="text-gray-300 text-sm">
              Earn 50% commission on direct referrals who purchase any product.
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-black font-bold text-xl">2</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Level 2 - 25%</h4>
            <p className="text-gray-300 text-sm">
              Earn 25% on purchases made by people your referrals bring in.
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-white font-bold text-xl">3</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Level 3 - 10%</h4>
            <p className="text-gray-300 text-sm">
              Earn 10% on third-level referrals for passive income growth.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReferralProgram;