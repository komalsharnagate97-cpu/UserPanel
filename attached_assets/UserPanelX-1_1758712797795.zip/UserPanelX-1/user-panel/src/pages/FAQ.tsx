import React, { useState, useEffect } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Search } from 'lucide-react';
import { getFAQs } from '../utils/localStorage';
import type { FAQItem } from '../types';

const FAQ: React.FC = () => {
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    const faqData = getFAQs();
    setFaqs(faqData);
  }, []);

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedItems(newExpanded);
  };

  const categories = ['all', ...Array.from(new Set(faqs.map(faq => faq.category)))];

  const filteredFAQs = faqs.filter(faq => {
    const matchesSearch = !searchQuery || 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const expandAll = () => {
    setExpandedItems(new Set(filteredFAQs.map(faq => faq.id)));
  };

  const collapseAll = () => {
    setExpandedItems(new Set());
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card bg-gradient-to-r from-primary/20 to-accent/20 border-primary/30">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-primary rounded-full mx-auto mb-4 flex items-center justify-center">
            <HelpCircle size={32} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Frequently Asked Questions</h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Find answers to common questions about our platform, products, and services. 
            Can't find what you're looking for? Contact our support team.
          </p>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="card">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="form-input pl-10"
              placeholder="Search questions and answers..."
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="form-input min-w-[200px]"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category === 'all' ? 'All Categories' : category}
              </option>
            ))}
          </select>

          {/* Expand/Collapse Controls */}
          <div className="flex space-x-2">
            <button
              onClick={expandAll}
              className="btn-secondary whitespace-nowrap"
            >
              Expand All
            </button>
            <button
              onClick={collapseAll}
              className="btn-secondary whitespace-nowrap"
            >
              Collapse All
            </button>
          </div>
        </div>

        {/* Results Info */}
        {searchQuery && (
          <div className="mt-4 text-sm text-gray-400">
            Found {filteredFAQs.length} result{filteredFAQs.length !== 1 ? 's' : ''} for "{searchQuery}"
          </div>
        )}
      </div>

      {/* FAQ Items */}
      <div className="space-y-4">
        {filteredFAQs.length === 0 ? (
          <div className="card text-center py-12">
            <HelpCircle className="text-gray-400 mx-auto mb-4" size={48} />
            <h3 className="text-xl font-semibold text-white mb-2">No FAQs Found</h3>
            <p className="text-gray-400">
              {searchQuery 
                ? 'Try adjusting your search query or category filter.'
                : 'No FAQs available at the moment.'
              }
            </p>
          </div>
        ) : (
          filteredFAQs.map((faq) => {
            const isExpanded = expandedItems.has(faq.id);
            
            return (
              <div key={faq.id} className="card hover:border-primary/50 transition-all">
                <button
                  onClick={() => toggleExpanded(faq.id)}
                  className="w-full flex items-center justify-between text-left"
                >
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <span className="px-3 py-1 bg-primary/20 text-primary text-xs font-medium rounded-full mr-3">
                        {faq.category}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-white pr-4">
                      {faq.question}
                    </h3>
                  </div>
                  <div className="flex-shrink-0 ml-4">
                    {isExpanded ? (
                      <ChevronUp className="text-primary" size={24} />
                    ) : (
                      <ChevronDown className="text-gray-400" size={24} />
                    )}
                  </div>
                </button>

                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-gray-700 animate-slide-down">
                    <div className="prose prose-invert max-w-none">
                      <p className="text-gray-300 leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Still Need Help */}
      <div className="card bg-gradient-to-r from-success/20 to-primary/20 border-success/30">
        <div className="text-center">
          <h3 className="text-xl font-bold text-white mb-4">Still need help?</h3>
          <p className="text-gray-300 mb-6">
            Can't find the answer you're looking for? Our support team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="btn-primary">
              Contact Support
            </button>
            <button className="btn-secondary">
              Request Feature
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card text-center">
          <div className="text-2xl font-bold text-primary mb-2">
            {faqs.length}
          </div>
          <p className="text-gray-400">Total Questions</p>
        </div>
        <div className="card text-center">
          <div className="text-2xl font-bold text-success mb-2">
            {categories.length - 1}
          </div>
          <p className="text-gray-400">Categories</p>
        </div>
        <div className="card text-center">
          <div className="text-2xl font-bold text-accent mb-2">
            95%
          </div>
          <p className="text-gray-400">Questions Resolved</p>
        </div>
      </div>
    </div>
  );
};

export default FAQ;