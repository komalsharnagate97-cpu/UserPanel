import React from 'react';
import { MessageCircle, Mail, Phone, MapPin, Clock, ExternalLink, Users, Headphones } from 'lucide-react';

const Contact: React.FC = () => {
  const contactInfo = {
    whatsapp: '+1-555-0123',
    email: 'support@userpanel.com',
    phone: '+1-555-0124',
    address: '123 Business Ave, Tech City, TC 12345',
    hours: 'Mon-Fri: 9:00 AM - 6:00 PM EST'
  };

  const handleWhatsAppContact = () => {
    const message = encodeURIComponent(
      "Hi! I'm reaching out from the User Panel. I'd like to learn more about your services."
    );
    const whatsappUrl = `https://wa.me/${contactInfo.whatsapp.replace(/[^0-9]/g, '')}?text=${message}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleEmailContact = () => {
    const subject = encodeURIComponent('Inquiry from User Panel');
    const body = encodeURIComponent(
      'Hello Support Team,\n\nI have a question about your services.\n\nThank you!'
    );
    const emailUrl = `mailto:${contactInfo.email}?subject=${subject}&body=${body}`;
    window.open(emailUrl, '_blank');
  };

  const handlePhoneContact = () => {
    window.open(`tel:${contactInfo.phone}`, '_self');
  };

  const supportTeam = [
    {
      name: 'Sarah Johnson',
      role: 'Customer Success Manager',
      specialization: 'Product Onboarding & Training',
      avatar: '👩‍💼',
      availability: 'Online'
    },
    {
      name: 'Mike Chen',
      role: 'Technical Support Lead',
      specialization: 'Technical Issues & Integration',
      avatar: '👨‍💻',
      availability: 'Online'
    },
    {
      name: 'Emily Rodriguez',
      role: 'Sales Consultant',
      specialization: 'Product Selection & Pricing',
      avatar: '👩‍💻',
      availability: 'Busy'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card bg-gradient-to-r from-primary/20 to-accent/20 border-primary/30">
        <div className="text-center">
          <div className="w-20 h-20 bg-gradient-primary rounded-full mx-auto mb-4 flex items-center justify-center">
            <MessageCircle size={32} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Connect With Us</h1>
          <p className="text-gray-300 max-w-2xl mx-auto">
            We're here to help you grow your business. Reach out through any of our channels 
            for support, questions, or just to say hello!
          </p>
        </div>
      </div>

      {/* Quick Contact Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <button
          onClick={handleWhatsAppContact}
          className="card-hover bg-gradient-to-br from-success/20 to-success/10 border-success/30 text-left"
        >
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-success rounded-full flex items-center justify-center mr-4">
              <MessageCircle className="text-white" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">WhatsApp</h3>
              <p className="text-gray-400 text-sm">Instant messaging</p>
            </div>
          </div>
          <p className="text-success font-medium mb-2">{contactInfo.whatsapp}</p>
          <p className="text-gray-300 text-sm">
            Get instant support and quick responses to your questions.
          </p>
          <div className="mt-4 flex items-center text-success text-sm">
            <span>Start Chat</span>
            <ExternalLink size={14} className="ml-1" />
          </div>
        </button>

        <button
          onClick={handleEmailContact}
          className="card-hover bg-gradient-to-br from-primary/20 to-primary/10 border-primary/30 text-left"
        >
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
              <Mail className="text-white" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Email</h3>
              <p className="text-gray-400 text-sm">Detailed support</p>
            </div>
          </div>
          <p className="text-primary font-medium mb-2">{contactInfo.email}</p>
          <p className="text-gray-300 text-sm">
            Send detailed questions and get comprehensive responses.
          </p>
          <div className="mt-4 flex items-center text-primary text-sm">
            <span>Send Email</span>
            <ExternalLink size={14} className="ml-1" />
          </div>
        </button>

        <button
          onClick={handlePhoneContact}
          className="card-hover bg-gradient-to-br from-accent/20 to-accent/10 border-accent/30 text-left"
        >
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mr-4">
              <Phone className="text-black" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Phone</h3>
              <p className="text-gray-400 text-sm">Direct conversation</p>
            </div>
          </div>
          <p className="text-accent font-medium mb-2">{contactInfo.phone}</p>
          <p className="text-gray-300 text-sm">
            Speak directly with our support team for immediate help.
          </p>
          <div className="mt-4 flex items-center text-accent text-sm">
            <span>Call Now</span>
            <ExternalLink size={14} className="ml-1" />
          </div>
        </button>
      </div>

      {/* Support Team */}
      <div className="card">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center">
          <Users className="mr-3 text-primary" size={24} />
          Our Support Team
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {supportTeam.map((member, index) => (
            <div key={index} className="bg-dark-200 rounded-lg p-6 text-center">
              <div className="text-4xl mb-4">{member.avatar}</div>
              <h4 className="text-lg font-semibold text-white mb-1">{member.name}</h4>
              <p className="text-primary text-sm font-medium mb-2">{member.role}</p>
              <p className="text-gray-400 text-sm mb-4">{member.specialization}</p>
              <div className="flex items-center justify-center">
                <div className={`w-2 h-2 rounded-full mr-2 ${
                  member.availability === 'Online' ? 'bg-success' : 'bg-accent'
                }`}></div>
                <span className={`text-sm font-medium ${
                  member.availability === 'Online' ? 'text-success' : 'text-accent'
                }`}>
                  {member.availability}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Information */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <MapPin className="mr-3 text-accent" size={24} />
            Contact Information
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-start">
              <Mail className="text-primary mt-1 mr-3 flex-shrink-0" size={20} />
              <div>
                <h4 className="font-semibold text-white mb-1">Email</h4>
                <p className="text-gray-300">{contactInfo.email}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Phone className="text-success mt-1 mr-3 flex-shrink-0" size={20} />
              <div>
                <h4 className="font-semibold text-white mb-1">Phone</h4>
                <p className="text-gray-300">{contactInfo.phone}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <MapPin className="text-accent mt-1 mr-3 flex-shrink-0" size={20} />
              <div>
                <h4 className="font-semibold text-white mb-1">Address</h4>
                <p className="text-gray-300">{contactInfo.address}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Clock className="text-primary mt-1 mr-3 flex-shrink-0" size={20} />
              <div>
                <h4 className="font-semibold text-white mb-1">Business Hours</h4>
                <p className="text-gray-300">{contactInfo.hours}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <Headphones className="mr-3 text-primary" size={24} />
            Support Options
          </h3>
          
          <div className="space-y-4">
            <div className="p-4 bg-dark-200 rounded-lg">
              <h4 className="font-semibold text-white mb-2">🚀 Priority Support</h4>
              <p className="text-gray-300 text-sm mb-2">
                For premium users - Get responses within 2 hours
              </p>
              <span className="text-accent text-sm font-medium">Available 24/7</span>
            </div>
            
            <div className="p-4 bg-dark-200 rounded-lg">
              <h4 className="font-semibold text-white mb-2">💬 Live Chat</h4>
              <p className="text-gray-300 text-sm mb-2">
                Real-time chat support for immediate assistance
              </p>
              <span className="text-success text-sm font-medium">Mon-Fri, 9AM-6PM</span>
            </div>
            
            <div className="p-4 bg-dark-200 rounded-lg">
              <h4 className="font-semibold text-white mb-2">📱 Remote Support</h4>
              <p className="text-gray-300 text-sm mb-2">
                Screen sharing and remote assistance available
              </p>
              <span className="text-primary text-sm font-medium">By appointment</span>
            </div>
            
            <div className="p-4 bg-dark-200 rounded-lg">
              <h4 className="font-semibold text-white mb-2">📚 Knowledge Base</h4>
              <p className="text-gray-300 text-sm mb-2">
                Extensive documentation and video tutorials
              </p>
              <span className="text-gray-400 text-sm font-medium">Available 24/7</span>
            </div>
          </div>
        </div>
      </div>

      {/* Response Time Guarantee */}
      <div className="card bg-gradient-to-r from-success/20 to-primary/20 border-success/30">
        <div className="text-center">
          <h3 className="text-xl font-bold text-white mb-4">Response Time Guarantee</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-2xl font-bold text-success mb-2">&lt; 2 hrs</div>
              <p className="text-gray-300 text-sm">WhatsApp & Live Chat</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary mb-2">&lt; 4 hrs</div>
              <p className="text-gray-300 text-sm">Email Support</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-accent mb-2">&lt; 24 hrs</div>
              <p className="text-gray-300 text-sm">Technical Issues</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;