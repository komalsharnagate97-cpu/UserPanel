import React from 'react';
import { 
  TrendingUp, Users, DollarSign, ShoppingCart, 
  Star, ArrowRight, Play, Target, Award, Zap 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const businessSnapshot = {
    totalEarnings: 12450,
    activeReferrals: 28,
    productsUsed: 4,
    successRate: 94
  };

  const successStories = [
    {
      name: 'Sarah Johnson',
      business: 'E-commerce Store',
      growth: '300% increase in sales',
      tool: 'WhatsApp Automation',
      image: '👩‍💼'
    },
    {
      name: 'Michael Chen',
      business: 'Digital Marketing',
      growth: '50+ new clients monthly',
      tool: 'Bulk IVR Calls',
      image: '👨‍💻'
    },
    {
      name: 'Emily Rodriguez',
      business: 'Real Estate',
      growth: 'Automated lead generation',
      tool: 'Map Extractor Pro',
      image: '👩‍🏫'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Greeting Section */}
      <div className="gradient-primary rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">
              Welcome back, {user?.fullName?.split(' ')[0]}! 👋
            </h1>
            <p className="text-blue-100">
              Great to see you again. Let's continue building your {user?.businessCategory} business.
            </p>
          </div>
          <div className="hidden md:block">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
              <Zap size={32} className="text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Business Snapshot */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card hover:border-primary transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-success/20 rounded-lg">
              <DollarSign className="text-success" size={24} />
            </div>
            <span className="text-success text-sm font-medium">+15%</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">
            ${businessSnapshot.totalEarnings.toLocaleString()}
          </h3>
          <p className="text-gray-400 text-sm">Total Earnings</p>
        </div>

        <div className="card hover:border-primary transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-primary/20 rounded-lg">
              <Users className="text-primary" size={24} />
            </div>
            <span className="text-primary text-sm font-medium">+8</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">
            {businessSnapshot.activeReferrals}
          </h3>
          <p className="text-gray-400 text-sm">Active Referrals</p>
        </div>

        <div className="card hover:border-primary transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-accent/20 rounded-lg">
              <ShoppingCart className="text-accent" size={24} />
            </div>
            <span className="text-accent text-sm font-medium">New</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">
            {businessSnapshot.productsUsed}
          </h3>
          <p className="text-gray-400 text-sm">Products Used</p>
        </div>

        <div className="card hover:border-primary transition-colors">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-success/20 rounded-lg">
              <TrendingUp className="text-success" size={24} />
            </div>
            <span className="text-success text-sm font-medium">+2%</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">
            {businessSnapshot.successRate}%
          </h3>
          <p className="text-gray-400 text-sm">Success Rate</p>
        </div>
      </div>

      {/* Motivational Highlight */}
      <div className="card bg-gradient-to-r from-primary/10 to-accent/10 border-primary/30">
        <div className="flex items-center">
          <div className="p-4 bg-gradient-primary rounded-full mr-6">
            <Target size={32} className="text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">You're on Fire! 🔥</h3>
            <p className="text-gray-300 mb-3">
              Your business is growing faster than 87% of users on our platform. 
              Keep up the amazing work and watch your success multiply!
            </p>
            <button className="btn-primary">
              View Growth Analytics <ArrowRight size={16} className="ml-2" />
            </button>
          </div>
        </div>
      </div>

      {/* Success Stories Carousel */}
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Success Stories</h3>
          <button className="text-primary hover:text-accent text-sm font-medium flex items-center">
            View All <ArrowRight size={16} className="ml-1" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {successStories.map((story, index) => (
            <div key={index} className="bg-dark-200 rounded-lg p-4 hover:bg-dark-100 transition-colors">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center text-xl mr-3">
                  {story.image}
                </div>
                <div>
                  <h4 className="font-semibold text-white">{story.name}</h4>
                  <p className="text-gray-400 text-sm">{story.business}</p>
                </div>
              </div>
              <p className="text-success font-semibold mb-2">{story.growth}</p>
              <p className="text-gray-300 text-sm mb-3">
                Using <span className="text-primary font-medium">{story.tool}</span>
              </p>
              <button className="text-primary hover:text-accent text-sm font-medium flex items-center">
                <Play size={14} className="mr-1" /> Watch Story
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Mini Performance Snapshot */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Award className="mr-2 text-accent" size={20} />
            Recent Achievements
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-dark-200 rounded-lg">
              <span className="text-gray-300">First Referral Bonus</span>
              <span className="text-success font-semibold">$50</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-dark-200 rounded-lg">
              <span className="text-gray-300">Product Setup Complete</span>
              <span className="text-primary font-semibold">100%</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-dark-200 rounded-lg">
              <span className="text-gray-300">Profile Completion</span>
              <span className="text-accent font-semibold">85%</span>
            </div>
          </div>
        </div>

        {/* Campaign Teaser */}
        <div className="card bg-gradient-to-br from-accent/20 to-primary/20 border-accent/30">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Star className="mr-2 text-accent" size={20} />
            Limited Time Offer
          </h3>
          <div className="mb-4">
            <h4 className="text-white font-bold mb-2">Holiday Special Campaign</h4>
            <p className="text-gray-300 text-sm mb-3">
              Get 50% off on all premium features and earn double referral commissions 
              until December 31st. Don't miss out!
            </p>
            <div className="flex items-center text-accent text-sm mb-3">
              <span className="font-semibold">Ends in: 23 days</span>
            </div>
          </div>
          <button className="btn-secondary w-full">
            Claim Offer Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;