import React, { useState } from 'react';
import { CreditCard, Search } from 'lucide-react';
import type { Product } from '../types';

const Products: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const products: Product[] = [
    {
      id: 'whatsapp-automation',
      name: 'WhatsApp Automation',
      emoji: '💬',
      description: 'Automate your WhatsApp business communications with smart chatbots, bulk messaging, and customer engagement tools.',
      videoLink: 'https://example.com/whatsapp-demo',
      hasAI: true,
      price: 99,
      features: ['Bulk Messaging', 'Auto Replies', 'Customer Segmentation', 'Analytics Dashboard']
    },
    {
      id: 'wasender',
      name: 'Wasender',
      emoji: '📱',
      description: 'Professional WhatsApp marketing tool with advanced scheduling, templates, and campaign management features.',
      videoLink: 'https://example.com/wasender-demo',
      hasAI: true,
      price: 149,
      features: ['Campaign Management', 'Message Templates', 'Contact Management', 'Delivery Reports']
    },
    {
      id: 'ready-grow',
      name: 'Ready + Grow',
      emoji: '🚀',
      description: 'Complete business growth suite with CRM, lead generation, and automated follow-up systems.',
      videoLink: 'https://example.com/ready-grow-demo',
      hasAI: true,
      price: 199,
      features: ['CRM Integration', 'Lead Generation', 'Automated Follow-ups', 'Sales Pipeline']
    },
    {
      id: 'map-extractor',
      name: 'Map Extractor',
      emoji: '🗺️',
      description: 'Extract business data from Google Maps for lead generation, market research, and competitor analysis.',
      videoLink: 'https://example.com/map-extractor-demo',
      hasAI: false,
      price: 79,
      features: ['Google Maps Scraping', 'Business Data Export', 'Contact Information', 'Location Analytics']
    },
    {
      id: 'digital-visiting-card',
      name: 'Digital Visiting Card',
      emoji: '💳',
      description: 'Create professional digital business cards with QR codes, contact sharing, and analytics tracking.',
      videoLink: 'https://example.com/digital-card-demo',
      hasAI: false,
      price: 49,
      features: ['QR Code Generation', 'Contact Sharing', 'Analytics Tracking', 'Custom Designs']
    },
    {
      id: 'bulk-ivr-calls',
      name: 'Bulk IVR Calls',
      emoji: '📞',
      description: 'Automated voice calling system for marketing campaigns, notifications, and customer engagement.',
      videoLink: 'https://example.com/ivr-demo',
      hasAI: true,
      price: 129,
      features: ['Voice Broadcasting', 'Call Scheduling', 'Response Tracking', 'Custom Messages']
    },
    {
      id: 'website-service',
      name: 'Website Service',
      emoji: '🌐',
      description: 'Professional website development and maintenance service for businesses of all sizes.',
      videoLink: 'https://example.com/website-demo',
      hasAI: false,
      price: 299,
      features: ['Custom Design', 'Mobile Responsive', 'SEO Optimized', 'Maintenance Support']
    }
  ];

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleBuyProduct = (product: Product) => {
    console.log(`Payment initiated for ${product.name} - $${product.price}`);
    alert(`Payment initiated for ${product.name}!\nAmount: $${product.price}\n\nThis is a demo - no real payment will be processed.`);
  };

  const handleWatchDemo = (product: Product) => {
    console.log(`Watching demo for ${product.name}`);
    alert(`Demo video for ${product.name} would open here.\n\nDemo URL: ${product.videoLink}`);
  };

  const toggleAI = (product: Product) => {
    if (product.hasAI) {
      console.log(`AI Assistant toggled for ${product.name}`);
      alert(`AI Assistant for ${product.name} is now active!\n\nThis feature helps you optimize your campaigns and automate tasks.`);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Products List */}
      <div className="lg:col-span-1">
        <div className="card h-full">
          <h2 className="text-xl font-bold text-white mb-6 flex items-center">
            <Search className="mr-3 text-primary" size={24} />
            Our Products
          </h2>
          
          <div className="space-y-3 max-h-[70vh] overflow-y-auto">
            {products.map((product) => (
              <div
                key={product.id}
                onClick={() => handleProductSelect(product)}
                className={`p-4 rounded-lg cursor-pointer transition-all duration-200 ${
                  selectedProduct?.id === product.id
                    ? 'bg-primary text-white border border-primary shadow-lg'
                    : 'bg-dark-200 hover:bg-dark-100 border border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <span className="text-2xl mr-3">{product.emoji}</span>
                    <span className="font-semibold">{product.name}</span>
                  </div>
                  {product.hasAI && (
                    <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                  )}
                </div>
                <p className={`text-sm ${
                  selectedProduct?.id === product.id ? 'text-blue-100' : 'text-gray-400'
                }`}>
                  {product.description.slice(0, 80)}...
                </p>
                <div className="flex items-center justify-between mt-3">
                  <span className={`font-bold ${
                    selectedProduct?.id === product.id ? 'text-white' : 'text-primary'
                  }`}>
                    ${product.price}
                  </span>
                  {product.hasAI && (
                    <span className="text-xs bg-accent text-black px-2 py-1 rounded-full font-medium">
                      AI
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Product Details */}
      <div className="lg:col-span-2">
        <div className="card h-full">
          {selectedProduct ? (
            <div className="h-full flex flex-col">
              {/* Product Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <span className="text-4xl mr-4">{selectedProduct.emoji}</span>
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-1">
                      {selectedProduct.name}
                    </h2>
                    <p className="text-primary font-semibold text-lg">
                      ${selectedProduct.price}
                    </p>
                  </div>
                </div>
                {selectedProduct.hasAI && (
                  <button
                    onClick={() => toggleAI(selectedProduct)}
                    className="btn-secondary"
                  >
                    🤖 AI Assistant
                  </button>
                )}
              </div>

              {/* Product Description */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-white mb-3">Description</h3>
                <p className="text-gray-300 leading-relaxed">
                  {selectedProduct.description}
                </p>
              </div>

              {/* Features */}
              <div className="mb-6 flex-1">
                <h3 className="text-lg font-semibold text-white mb-3">Key Features</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedProduct.features?.map((feature, index) => (
                    <div key={index} className="flex items-center bg-dark-200 p-3 rounded-lg">
                      <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 mt-auto">
                <button
                  onClick={() => handleWatchDemo(selectedProduct)}
                  className="btn-secondary flex-1 flex items-center justify-center"
                >
                  📹 Watch Demo
                </button>
                <button
                  onClick={() => handleBuyProduct(selectedProduct)}
                  className="btn-primary flex-1 flex items-center justify-center"
                >
                  <CreditCard size={16} className="mr-2" />
                  Buy Now - ${selectedProduct.price}
                </button>
              </div>

              {/* Demo Info */}
              <div className="mt-4 p-4 bg-dark-200 rounded-lg">
                <p className="text-gray-400 text-sm text-center">
                  💡 <strong>Demo Mode:</strong> All purchases are simulated for demonstration purposes. 
                  No real payments will be processed.
                </p>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <div className="w-24 h-24 bg-dark-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="text-gray-400" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  Select a Product
                </h3>
                <p className="text-gray-400 max-w-md">
                  Choose a product from the list on the left to view details, 
                  watch demos, and explore features.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Products;