import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, MapPin, Globe, Briefcase, Edit3, Save, X, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { saveUser } from '../utils/localStorage';
import type { User as UserType } from '../types';

const Profile: React.FC = () => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState<UserType | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (user) {
      setEditedUser({ ...user });
    }
  }, [user]);

  const businessCategories = [
    'E-commerce', 'Technology', 'Healthcare', 'Education', 'Finance', 
    'Real Estate', 'Food & Beverage', 'Retail', 'Manufacturing', 
    'Consulting', 'Marketing', 'Other'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    if (!editedUser) return;
    
    const { name, value } = e.target;
    setEditedUser(prev => prev ? { ...prev, [name]: value } : null);
  };

  const handleSave = () => {
    if (!editedUser) return;

    setErrors([]);
    
    // Validation
    const newErrors: string[] = [];
    if (!editedUser.fullName) newErrors.push('Full name is required');
    if (!editedUser.mobile) newErrors.push('Mobile number is required');
    if (!editedUser.email) newErrors.push('Email is required');
    if (!editedUser.city) newErrors.push('City is required');
    if (!editedUser.country) newErrors.push('Country is required');
    if (!editedUser.businessCategory) newErrors.push('Business category is required');
    
    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      // Save to localStorage
      saveUser(editedUser);
      
      // In a real app, you'd also update the auth context
      setIsEditing(false);
      setSuccessMessage('Profile updated successfully!');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (error) {
      setErrors(['Failed to update profile. Please try again.']);
    }
  };

  const handleCancel = () => {
    setEditedUser(user ? { ...user } : null);
    setIsEditing(false);
    setErrors([]);
  };

  const getProfileCompletionPercentage = () => {
    if (!user) return 0;
    
    const fields = [
      user.fullName, user.mobile, user.email, 
      user.city, user.country, user.businessCategory
    ];
    
    const filledFields = fields.filter(field => field && field.trim() !== '').length;
    return Math.round((filledFields / fields.length) * 100);
  };

  const completionPercentage = getProfileCompletionPercentage();

  if (!user) {
    return (
      <div className="card text-center py-12">
        <User className="text-gray-400 mx-auto mb-4" size={48} />
        <h3 className="text-xl font-semibold text-white mb-2">No User Data</h3>
        <p className="text-gray-400">Please log in to view your profile.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card bg-gradient-to-r from-primary/20 to-accent/20 border-primary/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mr-6">
              <span className="text-white font-bold text-2xl">
                {user.fullName?.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">{user.fullName}</h1>
              <p className="text-gray-300">{user.businessCategory}</p>
              <p className="text-gray-400 text-sm">{user.email}</p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="mb-2">
              <span className="text-sm text-gray-400">Profile Completion</span>
            </div>
            <div className="flex items-center">
              <div className="w-24 bg-dark-200 rounded-full h-2 mr-3">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${
                    completionPercentage === 100 ? 'bg-success' : 'bg-primary'
                  }`}
                  style={{ width: `${completionPercentage}%` }}
                ></div>
              </div>
              <span className={`font-semibold ${
                completionPercentage === 100 ? 'text-success' : 'text-primary'
              }`}>
                {completionPercentage}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Success Message */}
      {successMessage && (
        <div className="bg-success/20 border border-success rounded-lg p-4 flex items-center">
          <Check className="text-success mr-3" size={20} />
          <span className="text-success font-medium">{successMessage}</span>
        </div>
      )}

      {/* Error Messages */}
      {errors.length > 0 && (
        <div className="bg-error/10 border border-error rounded-lg p-4">
          <ul className="text-error text-sm space-y-1">
            {errors.map((error, index) => (
              <li key={index}>• {error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Profile Information */}
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Profile Information</h3>
          {!isEditing ? (
            <button
              onClick={() => setIsEditing(true)}
              className="btn-primary flex items-center"
            >
              <Edit3 size={16} className="mr-2" />
              Edit Profile
            </button>
          ) : (
            <div className="flex space-x-2">
              <button
                onClick={handleSave}
                className="btn-success flex items-center"
              >
                <Save size={16} className="mr-2" />
                Save
              </button>
              <button
                onClick={handleCancel}
                className="btn-secondary flex items-center"
              >
                <X size={16} className="mr-2" />
                Cancel
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Full Name */}
          <div>
            <label className="form-label">
              <User size={16} className="inline mr-2" />
              Full Name
            </label>
            {isEditing ? (
              <input
                type="text"
                name="fullName"
                value={editedUser?.fullName || ''}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your full name"
              />
            ) : (
              <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">{user.fullName}</p>
            )}
          </div>

          {/* Mobile */}
          <div>
            <label className="form-label">
              <Phone size={16} className="inline mr-2" />
              Mobile Number
            </label>
            {isEditing ? (
              <input
                type="tel"
                name="mobile"
                value={editedUser?.mobile || ''}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter mobile number"
              />
            ) : (
              <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">{user.mobile}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label className="form-label">
              <Mail size={16} className="inline mr-2" />
              Email Address
            </label>
            {isEditing ? (
              <input
                type="email"
                name="email"
                value={editedUser?.email || ''}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter email address"
              />
            ) : (
              <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">{user.email}</p>
            )}
          </div>

          {/* Business Category */}
          <div>
            <label className="form-label">
              <Briefcase size={16} className="inline mr-2" />
              Business Category
            </label>
            {isEditing ? (
              <select
                name="businessCategory"
                value={editedUser?.businessCategory || ''}
                onChange={handleInputChange}
                className="form-input"
              >
                <option value="">Select category</option>
                {businessCategories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            ) : (
              <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">{user.businessCategory}</p>
            )}
          </div>

          {/* City */}
          <div>
            <label className="form-label">
              <MapPin size={16} className="inline mr-2" />
              City
            </label>
            {isEditing ? (
              <input
                type="text"
                name="city"
                value={editedUser?.city || ''}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your city"
              />
            ) : (
              <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">{user.city}</p>
            )}
          </div>

          {/* Country */}
          <div>
            <label className="form-label">
              <Globe size={16} className="inline mr-2" />
              Country
            </label>
            {isEditing ? (
              <input
                type="text"
                name="country"
                value={editedUser?.country || ''}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your country"
              />
            ) : (
              <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">{user.country}</p>
            )}
          </div>
        </div>
      </div>

      {/* Account Information */}
      <div className="card">
        <h3 className="text-xl font-bold text-white mb-6">Account Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="form-label">Member Since</label>
            <p className="text-gray-300 bg-dark-200 p-3 rounded-lg">
              {new Date(user.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
          </div>
          
          <div>
            <label className="form-label">Account Status</label>
            <div className="flex items-center bg-dark-200 p-3 rounded-lg">
              <div className="w-2 h-2 bg-success rounded-full mr-2"></div>
              <span className="text-success font-medium">Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Account Actions */}
      <div className="card">
        <h3 className="text-xl font-bold text-white mb-6">Account Actions</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-dark-200 rounded-lg">
            <div>
              <h4 className="font-medium text-white">Change Password</h4>
              <p className="text-gray-400 text-sm">Update your account password</p>
            </div>
            <button className="btn-secondary">
              Change Password
            </button>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-dark-200 rounded-lg">
            <div>
              <h4 className="font-medium text-white">Export Data</h4>
              <p className="text-gray-400 text-sm">Download your account data</p>
            </div>
            <button className="btn-secondary">
              Export Data
            </button>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-error/20 border border-error/30 rounded-lg">
            <div>
              <h4 className="font-medium text-white">Delete Account</h4>
              <p className="text-gray-400 text-sm">Permanently delete your account</p>
            </div>
            <button className="btn-error">
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;