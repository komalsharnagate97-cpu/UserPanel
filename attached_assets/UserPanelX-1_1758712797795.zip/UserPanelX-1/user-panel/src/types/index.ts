// User types
export interface User {
  id: string;
  fullName: string;
  mobile: string;
  email: string;
  city: string;
  country: string;
  businessCategory: string;
  createdAt: string;
}

// Auth types
export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (userData: SignupData) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

export interface SignupData {
  fullName: string;
  mobile: string;
  email: string;
  city: string;
  country: string;
  businessCategory: string;
  password: string;
}

// Product types
export interface Product {
  id: string;
  name: string;
  emoji: string;
  description: string;
  videoLink?: string;
  hasAI: boolean;
  price?: number;
  features?: string[];
}

// Referral types
export interface ReferralData {
  level: number;
  count: number;
  earnings: number;
  users: Array<{
    name: string;
    joinDate: string;
    earnings: number;
  }>;
}

// Notification types
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  createdAt: string;
}

// FAQ types
export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}