import type { User, SignupData, Notification, FAQItem } from '../types';

const STORAGE_KEYS = {
  USER: 'user_panel_user',
  USERS: 'user_panel_users',
  NOTIFICATIONS: 'user_panel_notifications',
  FAQS: 'user_panel_faqs',
  REFERRAL_DATA: 'user_panel_referrals',
} as const;

// User management
export const saveUser = (user: User): void => {
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
};

export const getUser = (): User | null => {
  const userData = localStorage.getItem(STORAGE_KEYS.USER);
  return userData ? JSON.parse(userData) : null;
};

export const removeUser = (): void => {
  localStorage.removeItem(STORAGE_KEYS.USER);
};

// Users database (for login/signup)
export const saveUserToDatabase = (userData: SignupData): User => {
  const users = getAllUsers();
  const newUser: User = {
    id: Date.now().toString(),
    fullName: userData.fullName,
    mobile: userData.mobile,
    email: userData.email,
    city: userData.city,
    country: userData.country,
    businessCategory: userData.businessCategory,
    createdAt: new Date().toISOString(),
  };
  
  users.push(newUser);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  return newUser;
};

export const getAllUsers = (): User[] => {
  const usersData = localStorage.getItem(STORAGE_KEYS.USERS);
  return usersData ? JSON.parse(usersData) : [];
};

export const findUserByEmail = (email: string): User | null => {
  const users = getAllUsers();
  return users.find(user => user.email === email) || null;
};

// Password management (stored separately for security simulation)
export const saveUserPassword = (email: string, password: string): void => {
  const passwords = JSON.parse(localStorage.getItem('user_passwords') || '{}');
  passwords[email] = password; // In real app, this would be hashed
  localStorage.setItem('user_passwords', JSON.stringify(passwords));
};

export const validateUserPassword = (email: string, password: string): boolean => {
  const passwords = JSON.parse(localStorage.getItem('user_passwords') || '{}');
  return passwords[email] === password;
};

// Notifications
export const getNotifications = (): Notification[] => {
  const notifications = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
  if (!notifications) {
    // Initialize with sample notifications
    const initialNotifications: Notification[] = [
      {
        id: '1',
        title: 'Welcome to User Panel!',
        message: 'Thank you for joining our platform. Explore all the amazing features we have to offer.',
        type: 'success',
        isRead: false,
        createdAt: new Date().toISOString(),
      },
      {
        id: '2',
        title: 'New Product Available',
        message: 'Check out our latest WhatsApp Automation tool to boost your business communication.',
        type: 'info',
        isRead: false,
        createdAt: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: '3',
        title: 'Referral Program Update',
        message: 'Invite friends and earn up to 50% commission on their purchases!',
        type: 'info',
        isRead: true,
        createdAt: new Date(Date.now() - 172800000).toISOString(),
      },
    ];
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(initialNotifications));
    return initialNotifications;
  }
  return JSON.parse(notifications);
};

export const markNotificationAsRead = (id: string): void => {
  const notifications = getNotifications();
  const updated = notifications.map(notif => 
    notif.id === id ? { ...notif, isRead: true } : notif
  );
  localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
};

// FAQ data
export const getFAQs = (): FAQItem[] => {
  const faqs = localStorage.getItem(STORAGE_KEYS.FAQS);
  if (!faqs) {
    // Initialize with sample FAQs
    const initialFAQs: FAQItem[] = [
      {
        id: '1',
        question: 'How do I get started with the platform?',
        answer: 'After signing up, you can explore our dashboard to see all available products and services. Start by checking out Our Products section to find tools that match your business needs.',
        category: 'Getting Started',
      },
      {
        id: '2',
        question: 'What is the Referral Program?',
        answer: 'Our referral program allows you to earn commissions by inviting friends and colleagues to join our platform. You can earn up to 50% commission on their purchases across 3 levels.',
        category: 'Referral',
      },
      {
        id: '3',
        question: 'How do I contact support?',
        answer: 'You can reach us through WhatsApp, email, or phone. Visit the "Connect With Us" section for all our contact details and support channels.',
        category: 'Support',
      },
      {
        id: '4',
        question: 'Are there any setup fees?',
        answer: 'No, there are no setup fees. You only pay for the products and services you choose to purchase. Most of our tools offer free trials or demo versions.',
        category: 'Billing',
      },
      {
        id: '5',
        question: 'Can I customize the products for my business?',
        answer: 'Yes, most of our products are customizable to match your business requirements. Contact our support team to discuss specific customization needs.',
        category: 'Products',
      },
    ];
    localStorage.setItem(STORAGE_KEYS.FAQS, JSON.stringify(initialFAQs));
    return initialFAQs;
  }
  return JSON.parse(faqs);
};