import React, { createContext, useContext, useState, useEffect } from 'react';
import type { AuthContextType, User, SignupData } from '../types';
import {
  saveUser,
  getUser,
  removeUser,
  saveUserToDatabase,
  findUserByEmail,
  saveUserPassword,
  validateUserPassword,
} from '../utils/localStorage';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is already logged in
    const savedUser = getUser();
    if (savedUser) {
      setUser(savedUser);
    }
    setLoading(false);
  }, []);

  const signup = async (userData: SignupData): Promise<boolean> => {
    try {
      // Check if user already exists
      const existingUser = findUserByEmail(userData.email);
      if (existingUser) {
        throw new Error('User with this email already exists');
      }

      // Create new user
      const newUser = saveUserToDatabase(userData);
      saveUserPassword(userData.email, userData.password);
      
      // Log them in
      setUser(newUser);
      saveUser(newUser);
      
      return true;
    } catch (error) {
      console.error('Signup error:', error);
      return false;
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Find user by email
      const existingUser = findUserByEmail(email);
      if (!existingUser) {
        throw new Error('User not found');
      }

      // Validate password
      const isValidPassword = validateUserPassword(email, password);
      if (!isValidPassword) {
        throw new Error('Invalid password');
      }

      // Log them in
      setUser(existingUser);
      saveUser(existingUser);
      
      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    removeUser();
  };

  const value: AuthContextType = {
    user,
    login,
    signup,
    logout,
    isAuthenticated: !!user,
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-200 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};